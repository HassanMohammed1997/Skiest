package com.project.semicolon.skiest.adapter;

public class WeaklyWeatherAdapter  {
}
