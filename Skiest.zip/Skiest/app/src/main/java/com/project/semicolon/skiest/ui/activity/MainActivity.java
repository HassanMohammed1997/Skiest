package com.project.semicolon.skiest.ui.activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.project.semicolon.skiest.R;
import com.project.semicolon.skiest.databinding.MainActivityBinding;
import com.project.semicolon.skiest.model.WeatherResponse;
import com.project.semicolon.skiest.viewmodel.WeatherViewModel;

import java.lang.reflect.Field;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = MainActivity.class.getSimpleName();
    private MainActivityBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        binding = DataBindingUtil.setContentView(this, R.layout.activity_main);

        WeatherViewModel viewModel = ViewModelProviders.of(this)
                .get(WeatherViewModel.class);

        viewModel.getCurrentWeather().observe(this, new Observer<WeatherResponse>() {
            @Override
            public void onChanged(WeatherResponse response) {
                if (response != null) {
                    binding.location.setText(String.format("%s, %s", response.getName(),
                            response.getSys().getCountry()));

                    String main = response.getWeather().get(0).getMain();
                    binding.weatherDesc.setText(main);
                    int iconId = convertMainToIcon("ic_" + main.trim().toLowerCase(), R.drawable.class);

                    binding.weatherIcon.setImageResource(iconId);
                    binding.weatherTemp.setText(String.format("%s%s", response.getMain().getTemp()
                            , getString(R.string.celsius_degree)));



                }
            }
        });


    }

    private int convertMainToIcon(String main, Class<?> c) {
        try {
            Field f = c.getDeclaredField(main);
            return f.getInt(f);
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }


    }
}
