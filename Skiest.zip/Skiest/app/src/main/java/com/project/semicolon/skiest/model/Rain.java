package com.project.semicolon.skiest.model;

public class Rain {

    @Override
    public String toString() {
        return
                "Rain{" +
                        "}";
    }
}