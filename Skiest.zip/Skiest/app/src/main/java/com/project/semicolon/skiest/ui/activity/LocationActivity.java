package com.project.semicolon.skiest.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.easywaylocation.EasyWayLocation;
import com.example.easywaylocation.Listener;
import com.project.semicolon.skiest.R;

import static com.example.easywaylocation.EasyWayLocation.LOCATION_SETTING_REQUEST_CODE;

public class LocationActivity extends AppCompatActivity implements Listener {
    private EasyWayLocation location;
    private double lat, lon;
    public static final String TAG = LocationActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);

        location = new EasyWayLocation(this);
        location.setListener(this);
    }

    @Override
    public void locationOn() {
        //save location
        lat = location.getLatitude();
        lon = location.getLongitude();


    }

    @Override
    public void onPositionChanged() {
        Log.d(TAG, "onPositionChanged: " + location.toString());

    }

    @Override
    public void locationCancelled() {
        location.showAlertDialog("Location", "Message", null);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case LOCATION_SETTING_REQUEST_CODE:
                location.onActivityResult(resultCode);
                break;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        location.beginUpdates();
    }

    @Override
    protected void onPause() {
        super.onPause();
        location.endUpdates();
    }
}
