package com.project.semicolon.skiest;

public class Constants {
    public static final String KEY_LAT = "latitude";
    public static final String KEY_LONG = "longitude";
}
